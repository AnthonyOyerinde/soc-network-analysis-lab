# SOC Network Analysis Lab

## Overview

A hands-on cybersecurity lab focused on network reconnaissance, packet capture, and network traffic analysis using macOS, Nmap, and Wireshark.

The lab demonstrates basic Security Operations Center (SOC) workflows by generating controlled network traffic, capturing packets, analyzing communications, and documenting findings.

## Objectives

- Perform network reconnaissance using Nmap
- Capture network traffic using Wireshark
- Analyze ICMP communication
- Identify source and destination IP addresses
- Interpret network protocols and packet behavior
- Document security observations and findings

## Environment

- Host OS: macOS
- Network Interface: Wi-Fi (en0)
- Nmap: 7.99
- Wireshark
- Python 3

## Lab Workflow

Generate Traffic → Capture Packets → Filter Traffic → Analyze → Document Findings

## Investigations

- ICMP Traffic Analysis
- Nmap Reconnaissance

## Key Skills Demonstrated

- Packet capture and analysis
- Network reconnaissance
- TCP/IP fundamentals
- ICMP traffic analysis
- Network troubleshooting
- Security documentation

## Scope

All testing was performed against systems and network traffic under my control within a personal cybersecurity lab environment.
