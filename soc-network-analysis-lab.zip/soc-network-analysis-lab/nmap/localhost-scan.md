# Nmap Reconnaissance

## Objective

Perform network reconnaissance against the local host to identify reachable services.

## Tool

Nmap 7.99

## Scan

```bash
nmap -sV 192.168.1.234
```

## Result

The host was identified as reachable and the service/version detection scan completed successfully. No open TCP services were identified in the resulting output.

## Security Relevance

Service discovery is a common component of network reconnaissance. Identifying exposed services helps determine the attack surface of a system and can highlight services that require additional security controls.

## Scope

The scan was performed against my own Mac within a personal cybersecurity lab environment.
