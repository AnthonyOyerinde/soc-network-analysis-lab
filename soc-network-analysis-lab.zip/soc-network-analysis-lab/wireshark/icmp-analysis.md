# ICMP Traffic Analysis

## Objective

Capture and analyze ICMP traffic generated from the local host to a known external IP address.

## Test Configuration

| Item | Value |
|---|---|
| Source | 192.168.1.234 |
| Destination | 1.1.1.1 |
| Protocol | ICMP |
| Tool | Wireshark |
| Interface | Wi-Fi (en0) |

## Procedure

1. Started a Wireshark capture on the Wi-Fi interface.
2. Generated ICMP traffic with:

```bash
ping -c 5 1.1.1.1
```

3. Stopped the packet capture.
4. Applied the Wireshark display filter:

```text
icmp
```

5. Analyzed the request and response packets.

## Observations

The capture showed five ICMP Echo Requests from the local host and five corresponding Echo Replies from 1.1.1.1.

### Traffic Flow

```text
192.168.1.234
      |
      | ICMP Echo Request
      v
   1.1.1.1
      |
      | ICMP Echo Reply
      v
192.168.1.234
```

## Finding

Successful bidirectional ICMP communication was observed between the local host and 1.1.1.1.

Wireshark was used to identify the protocol, source, destination, packet sequence, and response behavior.

## Security Relevance

ICMP traffic can be useful during network monitoring because unusual ICMP activity may indicate reconnaissance, troubleshooting activity, or, in some situations, covert communication.

This controlled test established a baseline for normal ICMP behavior.

## Evidence

See `screenshots/icmp-capture.png`.
